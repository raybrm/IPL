﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExtensionMethods
{
    public static class MesExtensions
    {
        public static String inversion(this String s)
        {
            String res ="";
            for (int i = s.Length-1; i >= 0; i--)
            {
                res += s[i];
            }

            return res;

        }
    }
}
