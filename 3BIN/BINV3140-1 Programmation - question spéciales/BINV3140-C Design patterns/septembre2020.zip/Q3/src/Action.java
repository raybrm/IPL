public interface Action {
	void effectuer();
}
