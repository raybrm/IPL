public interface Vue {
	void update(DeplacementDisque d);
}
