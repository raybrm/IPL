import java.util.List;

public interface Deplacement {
	void stocker(List<DeplacementDisque> deplacements);
}
