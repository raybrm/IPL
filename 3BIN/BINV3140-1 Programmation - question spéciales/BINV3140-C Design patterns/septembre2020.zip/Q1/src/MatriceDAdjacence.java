import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public class MatriceDAdjacence extends Graph{
	
	private Map<Integer, Airport>  correspondanceIndiceAirport;
	private Map<Airport, Integer>  correspondanceAirportIndice;
	private Flight[][] matrice= new Flight[0][0];
	private int nbAirport=0;

	public MatriceDAdjacence() {
		super();
		correspondanceAirportIndice= new HashMap<Airport,Integer>();
		correspondanceIndiceAirport= new HashMap<Integer,Airport>();
	}

	@Override
	protected void ajouterSommet(Airport a) {
		correspondanceIndiceAirport.put(nbAirport,a);
		correspondanceAirportIndice.put(a, nbAirport);
		nbAirport++;
		Flight[][] matrice2= new Flight[nbAirport][nbAirport]; 
		for (int i=0;i<matrice.length;i++) {
			for (int j=0;i<matrice.length;i++) {
				matrice2[i][j]=matrice[i][j];
			}
		}
		matrice=matrice2;
	}

	@Override
	protected void ajouterArc(Flight f) {
		matrice[correspondanceAirportIndice.get(f.getSource())][correspondanceAirportIndice.get(f.getDestination())]=f;
		
	}

	@Override
	public Set<Flight> arcsSortants(Airport a) {
		Flight[] list= matrice[correspondanceAirportIndice.get(a)];
		Set<Flight> toReturn= new HashSet<Flight>();
		for (Flight f:list) {
			if(f!=null) toReturn.add(f);
		}
		return toReturn;
	}
	

	public void affiche() {
		for (int i=0;i<matrice.length;i++) {
			for(int j=0;j<matrice.length;j++) {
				System.out.print(matrice[i][j]+" "+"\t");
			}
			System.out.println();
		}
	}

	@Override
	public boolean sontAdjacents(Airport a1, Airport a2) {
		int i= correspondanceAirportIndice.get(a1);
		int j= correspondanceAirportIndice.get(a2);
		return !(matrice[i][j]==null && matrice[j][i]==null);
	}
	
	@Override
	public void bfs(String depart, String arrivee) {
		Set<Airport> visited = new HashSet<Airport>();
		Queue<Airport> queue = new LinkedList<Airport>();
		Airport departAir = correspondanceIataAirport.get(depart);
		queue.add(departAir);
		visited.add(departAir);
		Map<Airport, Flight> chemin = new HashMap<Airport, Flight>();
		while (!queue.isEmpty()) {
			Airport cur = queue.poll();
			Flight[] list = matrice[correspondanceAirportIndice.get(cur)];
			Set<Flight> set = new HashSet<Flight>();
			for (Flight f : list) {
				if (f != null)
					set.add(f);
			}
			for (Flight f : set) {
				if (!visited.contains(f.getDestination())) {
					queue.add(f.getDestination());
					visited.add(f.getDestination());
					chemin.put(f.getDestination(), f);
					if (f.getDestination().getIata().equals(arrivee)) {
						cur = f.getDestination();
						ArrayDeque<Flight> pile = new ArrayDeque<Flight>();
						while (!cur.equals(departAir)) {
							pile.push(chemin.get(cur));
							cur = chemin.get(cur).getSource();
						}
						while (!pile.isEmpty()) {
							System.out.println(pile.pop());
						}
					}
				}
			}
		}
	}

}
