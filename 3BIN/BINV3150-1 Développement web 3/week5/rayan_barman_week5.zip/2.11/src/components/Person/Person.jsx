import React from 'react'



const Person = ({ person }) => <p>{person.name}</p>

export default Person