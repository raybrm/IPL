import React from "react";

const Country = ({countrie}) => <p>{countrie.name}</p>

export default Country