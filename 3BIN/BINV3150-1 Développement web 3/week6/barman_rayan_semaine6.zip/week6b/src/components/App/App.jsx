import React from 'react'
import Opinions from "../Opinions/Opinions";
import Form from "../Form/Form";


const App = () => {
    console.log("Render App")

    return (
        <>
            <Opinions/>
            <Form/>
        </>
    )


}

export default App
