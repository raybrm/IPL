create function supprimertransaction(nom_source character varying, prenom_source character varying, compte_s character, nom_destination character varying, prenom_destination character varying, compte_d character, date_operation timestamp without time zone, montant_operation integer) returns integer
    language plpgsql
as
$$
DECLARE
	nb INTEGER:=0;
BEGIN
	IF NOT EXISTS(SELECT * FROM preprojet.comptes c, preprojet.utilisateurs u 
			    WHERE c.numero=compte_s AND c.id_utilisateur=u.id_utilisateur 
	  		    AND u.nom=nom_source and u.prenom=prenom_source) THEN
		RAISE 'compte source invalide';
	END IF;
	IF NOT EXISTS(SELECT * FROM preprojet.comptes c, preprojet.utilisateurs u 
			    WHERE c.numero=compte_d AND c.id_utilisateur=u.id_utilisateur 
                            AND u.nom=nom_destination and u.prenom=prenom_destination) THEN
		RAISE 'compte destination invalide';
	END IF;
	SELECT COUNT(*) FROM preprojet.operations o  WHERE o.compte_source=compte_s AND o.compte_destination=compte_d AND o.date_op=date_operation AND o.montant=montant_operation INTO nb;
	IF (nb=0) THEN RAISE 'aucune opération correspondante'; END IF;
	DELETE FROM preprojet.operations o WHERE o.compte_source=compte_s AND o.compte_destination=compte_d AND o.date_op=date_operation AND o.montant=montant_operation;
	RETURN nb;
END;
$$;

alter function supprimertransaction(varchar, varchar, char, varchar, varchar, char, timestamp, integer) owner to postgres;

