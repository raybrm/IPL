create function mise_a_jour_nb_stages() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
	
	UPDATE examen2019.enfants
	SET nb_stages = nb_stages + 1
	WHERE id_enfant = NEW.id_enfant;
	
	RETURN NEW;

END;
$$;

alter function mise_a_jour_nb_stages() owner to postgres;

