create view affichageevenements (id_event, nom, date, prix, salle, capacite, id_festival, festival, nb_tickets_vendu) as
SELECT e.id_evenement                                 AS id_event,
       e.nom_evenement                                AS nom,
       e.date,
       e.prix,
       s.nom_salle                                    AS salle,
       s.capacite,
       f.id_festival,
       f.nom_festival                                 AS festival,
       COALESCE(sum(r.nb_tickets_reserve), 0::bigint) AS nb_tickets_vendu
FROM projet.evenements e
         LEFT JOIN projet.festivals f ON e.id_festival = f.id_festival
         LEFT JOIN projet.salles s ON e.id_salle = s.id_salle
         LEFT JOIN projet.reservations r ON e.id_evenement = r.id_evenement
GROUP BY e.id_evenement, s.id_salle, f.id_festival
ORDER BY e.date DESC;

alter table affichageevenements
    owner to postgres;

