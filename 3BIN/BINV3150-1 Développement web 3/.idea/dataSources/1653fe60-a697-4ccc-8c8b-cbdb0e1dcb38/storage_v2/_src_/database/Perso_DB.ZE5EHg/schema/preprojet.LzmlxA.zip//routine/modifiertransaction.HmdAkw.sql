create function modifiertransaction(character varying, character varying, character, character varying, character varying, character, timestamp without time zone, integer) returns integer
    language plpgsql
as
$$
DECLARE
	nom_source ALIAS FOR $1 ;
	prenom_source ALIAS FOR $2;
	compte_source ALIAS FOR $3;
	nom_destination ALIAS FOR $4 ;
	prenom_destination ALIAS FOR $5;
	compte_destination ALIAS FOR $6;
	date_operation ALIAS FOR $7;
	montant_operation ALIAS FOR $8;
	id INTEGER := 0;
BEGIN 
	-- Si l'utilisateur source et le compte sont liées --
	IF  NOT EXISTS (SELECT * FROM preprojet.utilisateurs u, preprojet.comptes c
				WHERE u.prenom =  prenom_source 
				AND u.nom = nom_source
				AND u.id_utilisateur = c.id_utilisateur
				AND c.numero = compte_source) THEN 
						   
		RAISE foreign_key_violation;
	END IF;	
	
	-- Si l'utilisateur destination et le compte sont liées --
	IF  NOT EXISTS (SELECT * FROM preprojet.utilisateurs u, preprojet.comptes c
				WHERE u.prenom =  prenom_destination 
				AND u.nom = nom_destination
				AND u.id_utilisateur = c.id_utilisateur
				AND c.numero = compte_destination) THEN 
						   
		RAISE foreign_key_violation;
	END IF;
	
	IF (1<> (SELECT COUNT(*) FROM preprojet.operations o 
			 WHERE o.compte_source = compte_source  AND o.compte_destination = compte_destination
			 AND o.date_operation = date_operation)) THEN 
		
		RAISE 'operation invalide';
	END IF;
	
	UPDATE preprojet.operations o SET montant = montant_operation 
									WHERE o.compte_source = compte_source 
									AND o.compte_destination = compte_destination
									AND o.date_operation = date_operation
									RETURNING o.id_operation INTO id;
	
	RETURN id;
	
END;

$$;

alter function modifiertransaction(varchar, varchar, char, varchar, varchar, char, timestamp, integer) owner to postgres;

