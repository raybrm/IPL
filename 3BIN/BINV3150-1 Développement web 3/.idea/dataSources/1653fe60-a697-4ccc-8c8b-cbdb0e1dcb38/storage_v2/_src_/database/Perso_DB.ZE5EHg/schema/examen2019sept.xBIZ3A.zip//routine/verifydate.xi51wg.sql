create function verifydate() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN


	IF EXISTS (SELECT c.id_concert
		FROM examen2019Sept.concerts c
		WHERE c.id_concert = NEW.id_concert
		AND c.date IN (SELECT ca.date
					   FROM examen2019Sept.concerts ca, examen2019Sept.reservations r
					   WHERE ca.id_concert = r.id_concert 
					   AND r.id_concert <> NEW.id_concert
					   AND r.id_client = NEW.id_client)) THEN raise 'reservation déjà eu lieu ce jours là ';
	end if;
	
	IF EXISTS (SELECT c.id_concert
				FROM examen2019Sept.reservations r, examen2019Sept.concerts c
				WHERE r.id_concert = NEW.id_concert
				AND r.id_concert = c.id_concert 
				GROUP BY c.id_concert
				HAVING (SUM(r.nb_tickets) + NEW.nb_tickets) > nb_tickets_en_vente) THEN RAISE 'plus assez de tickets';
	end if;
	
	IF EXISTS (SELECT SUM(r.nb_tickets)
				FROM examen2019Sept.reservations r
				WHERE r.id_client = NEW.id_client 
				AND r.id_concert = NEW.id_concert
				HAVING (SUM(r.nb_tickets) + NEW.nb_tickets > 4 )) THEN RAISE 'peut pas reserver plus de 4 tickets pour ce concert';
	end if;
	return new;
	
END;
$$;

alter function verifydate() owner to postgres;

