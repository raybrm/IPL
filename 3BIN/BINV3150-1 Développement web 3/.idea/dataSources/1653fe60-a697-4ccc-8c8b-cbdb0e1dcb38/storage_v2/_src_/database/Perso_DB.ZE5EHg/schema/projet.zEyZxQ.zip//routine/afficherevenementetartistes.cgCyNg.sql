create function afficherevenementetartistes() returns SETOF record
    language plpgsql
as
$$
DECLARE
	sep VARCHAR;
	artistes VARCHAR;
	sortie RECORD;
	evenement_infos RECORD;
	evenement_concerts RECORD;
	nom_artiste VARCHAR(250);
	complet VARCHAR(40);

BEGIN
	FOR evenement_infos IN (SELECT * FROM projet.affichageEvenements) LOOP
		artistes :='';sep:='';
		FOR evenement_concerts IN ( SELECT * FROM projet.concerts c WHERE evenement_infos.id_event = c.id_evenement) LOOP
			SELECT a.nom_artiste FROM projet.artistes a WHERE a.id_artiste = evenement_concerts.id_artiste INTO nom_artiste;
			artistes := artistes || sep || nom_artiste;
			sep:=' + ';
		END LOOP;
		
		IF( evenement_infos.nb_tickets_vendu = evenement_infos.capacite) THEN
			complet := 'true';
		ELSE
			complet := 'false';
		END IF;
			
		
		SELECT evenement_infos.id_event, evenement_infos.nom , evenement_infos.date, evenement_infos.salle, artistes, evenement_infos.prix, complet INTO sortie;
		RETURN NEXT sortie;
	END LOOP;
	
RETURN;
END;
$$;

alter function afficherevenementetartistes() owner to postgres;

