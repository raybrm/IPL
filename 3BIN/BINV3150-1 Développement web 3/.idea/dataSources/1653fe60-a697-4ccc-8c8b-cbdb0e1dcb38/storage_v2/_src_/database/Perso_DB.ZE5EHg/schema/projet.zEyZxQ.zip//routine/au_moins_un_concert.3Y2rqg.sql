create function au_moins_un_concert() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
	-- Pas de reservation si il n'y a pas encore de concerts pour l'événement -- 
	IF NOT EXISTS( SELECT * FROM projet.concerts WHERE id_evenement = NEW.id_evenement) THEN RAISE 'Reservation Impossible : Pas encore de concert pour cette événement'; END IF;
	RETURN NEW;
END;
$$;

alter function au_moins_un_concert() owner to postgres;

