create function verification_ticket_disponible() returns trigger
    language plpgsql
as
$$
DECLARE
	tickets_vendu INTEGER := 0;
	capacite_salle INTEGER;
BEGIN
	-- Regarde le nombre de tickets disponible en fonction de la capacite de la salle AVANT de reserver --
	-- prend le nombre de tickets vendu au total pour cet événement--
	SELECT SUM(nb_tickets_reserve) 
	FROM projet.reservations r 
	WHERE r.id_evenement = NEW.id_evenement 
	GROUP BY r.id_evenement INTO tickets_vendu;
				
	IF (tickets_vendu is null) THEN tickets_vendu := 0; END IF;
	
	SELECT s.capacite
	FROM projet.evenements e , projet.salles s
	WHERE e.id_evenement = NEW.id_evenement 
	AND e.id_salle = s.id_salle INTO capacite_salle;
	
	IF (tickets_vendu + NEW.nb_tickets_reserve > capacite_salle) THEN RAISE 'Plus de tickets disponible pour cet événement'; END IF;
	
	RETURN NEW;
END;
$$;

alter function verification_ticket_disponible() owner to postgres;

