create function updatenumero() returns trigger
    language plpgsql
as
$$
DECLARE
	dernierNumero integer :=0;
BEGIN	
	SELECT COUNT(r.numero_reservation)
	FROM examen2019Sept.reservations r
	WHERE r.id_concert = NEW.id_concert INTO dernierNumero;
	
	NEW.numero_reservation = dernierNumero +1;
	
	return new;
	
END;
$$;

alter function updatenumero() owner to postgres;

