create function inscription(enfant_id integer, stage_id integer) returns integer
    language plpgsql
as
$$
DECLARE
	nb_inscription INTEGER;
BEGIN
	
	--Ajoute l'inscription --
	INSERT INTO examen2019.inscriptions(id_inscription, id_enfant, id_stage)
	VALUES (DEFAULT, enfant_id, stage_id);
	
	-- renvoie le nombre d'inscription aux stages se déroulant la même semaine que le stage en paramètre --
	SELECT COUNT(*)
	FROM examen2019.inscriptions i, examen2019.stages s
	WHERE i.id_stage = s.id_stage
	AND s.numero_semaine = (SELECT x.numero_semaine
						   FROM examen2019.stages x
						   WHERE x.id_stage = stage_id) INTO nb_inscription;
	
	RETURN nb_inscription;

END;
$$;

alter function inscription(integer, integer) owner to postgres;

