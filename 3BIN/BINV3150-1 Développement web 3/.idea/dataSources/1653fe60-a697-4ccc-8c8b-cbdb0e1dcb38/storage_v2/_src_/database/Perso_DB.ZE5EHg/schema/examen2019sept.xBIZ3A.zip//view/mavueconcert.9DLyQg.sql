create view mavueconcert(nom_artiste, date_concert, nom_salle, nombre_ticket_reserve) as
SELECT c.nom_artiste,
       c.date                                 AS date_concert,
       c.nom_salle,
       COALESCE(sum(r.nb_tickets), 0::bigint) AS nombre_ticket_reserve
FROM examen2019sept.concerts c
         LEFT JOIN examen2019sept.reservations r ON c.id_concert = r.id_concert
GROUP BY c.id_concert;

alter table mavueconcert
    owner to postgres;

