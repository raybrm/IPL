create function reservations_meme_date() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
	-- lorsque le client a déjà reservé des tickets pour un autre événement se déroulant à la même date --
	-- Compare la date de l'événement qu'on veut ajouter avec la date des autres événements--
	-- Dans le 2e select les événement select doivent être différent de celui rajouter, sinon ou pourra pas reserver plusieurs tickets pour le même événement plusieurs fois--
	IF EXISTS (SELECT * FROM projet.evenements e
				WHERE e.id_evenement = NEW.id_evenement
				AND e.date IN (SELECT ev.date FROM projet.reservations r , projet.evenements ev 
							   WHERE r.id_utilisateur = NEW.id_utilisateur AND ev.id_evenement = r.id_evenement
							   AND ev.id_evenement <> NEW.id_evenement)) THEN
			
			RAISE 'Peut pas reserver un événement à la même date';
	END IF;
	
	RETURN NEW;
END;
$$;

alter function reservations_meme_date() owner to postgres;

