create function ajouterutilisateur(nom character varying, email character varying, mot_de_passe character varying) returns integer
    language plpgsql
as
$$
DECLARE
	id INTEGER;
BEGIN
	INSERT INTO projet.utilisateurs (id_utilisateur, nom_utilisateur, email, mot_de_passe)
	VALUES (DEFAULT, nom, email, mot_de_passe)  RETURNING id_utilisateur INTO id;
	
	RETURN id;
END;
$$;

alter function ajouterutilisateur(varchar, varchar, varchar) owner to postgres;

