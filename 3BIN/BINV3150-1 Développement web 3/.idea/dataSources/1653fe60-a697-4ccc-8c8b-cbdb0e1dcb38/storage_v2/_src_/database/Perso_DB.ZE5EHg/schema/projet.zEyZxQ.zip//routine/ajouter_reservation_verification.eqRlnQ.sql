create function ajouter_reservation_verification() returns trigger
    language plpgsql
as
$$
DECLARE
	nombre_tickets_deja_reserve INTEGER := 0;
BEGIN	
	-- Declenche dans le cas d'un ajout dans la table reservation --
	-- Pas plus de 4 resevration pour un même évenement pour un utilisateur --

	-- Slectionne le nombre de ticket reserve pour 1 user --
	SELECT SUM(r.nb_tickets_reserve)
	FROM projet.reservations r
	WHERE r.id_evenement = NEW.id_evenement
	AND r.id_utilisateur = NEW.id_utilisateur
	GROUP BY(r.id_utilisateur) INTO nombre_tickets_deja_reserve;
	
	IF ((nombre_tickets_deja_reserve + NEW.nb_tickets_reserve) > 4) THEN 
		RAISE 'Nombre maximum de tickets reservés dépassés';
	END IF;
	
	RETURN NEW;
END;
$$;

alter function ajouter_reservation_verification() owner to postgres;

