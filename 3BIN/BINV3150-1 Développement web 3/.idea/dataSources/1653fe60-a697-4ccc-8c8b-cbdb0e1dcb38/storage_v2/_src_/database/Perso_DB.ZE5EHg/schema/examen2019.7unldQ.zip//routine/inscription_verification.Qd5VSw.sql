create function inscription_verification() returns trigger
    language plpgsql
as
$$
DECLARE
	nbre_inscription INTEGER :=0;
BEGIN
	-- Exception lorsqu'un enfant d'un sexe veut s'inscrire à un stage réservé au sexe opposé  
	IF EXISTS (SELECT e.id_enfant 
			   FROM examen2019.enfants e 
			   WHERE e.id_enfant = NEW.id_enfant
			   AND e.sexe <> (SELECT s.sexe_participant
							FROM examen2019.stages s
							WHERE s.id_stage = NEW.id_stage))THEN RAISE 'Enfant de sexe opposé';
	
	END IF;
	-- lorsque l'enfant est déjà inscrit à un stage la même semaine --
	IF EXISTS (SELECT s.id_stage
			   FROM examen2019.stages s
			   WHERE s.id_stage = NEW.id_stage
			   AND s.numero_semaine IN (SELECT st.numero_semaine
										  FROM examen2019.stages st, examen2019.inscriptions i
										  WHERE i.id_enfant = NEW.id_enfant
									      AND st.id_stage = i.id_stage)) THEN RAISE 'Enfant déjà inscrit à un stage la même semaine';
	
	END IF;
	
	-- Lorsque le stage est complet --
	SELECT COALESCE(COUNT(i.id_stage),0)
	FROM examen2019.inscriptions i
	WHERE i.id_stage = NEW.id_stage INTO nbre_inscription;
	
	IF EXISTS (SELECT s.id_stage FROM examen2019.stages s WHERE s.id_stage = NEW.id_stage AND nbre_inscription >= s.max_participant) THEN RAISE 'Le stage est complet';
	END IF;

	RETURN NEW;

END;
$$;

alter function inscription_verification() owner to postgres;

