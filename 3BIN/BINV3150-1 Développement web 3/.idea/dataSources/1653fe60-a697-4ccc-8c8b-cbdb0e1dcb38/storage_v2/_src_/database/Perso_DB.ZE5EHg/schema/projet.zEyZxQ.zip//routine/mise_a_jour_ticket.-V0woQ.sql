create function mise_a_jour_ticket() returns trigger
    language plpgsql
as
$$
DECLARE
	concert RECORD;
BEGIN
	-- Met à jour les tickets des artistes d'un evenement lors d'une reservation--
	-- prend tous les concerts de l'evenement en question--
	FOR concert IN( SELECT * FROM projet.concerts c WHERE c.id_evenement = NEW.id_evenement) LOOP
		UPDATE projet.artistes
		SET nb_tickets_vendu = nb_tickets_vendu + NEW.nb_tickets_reserve
		WHERE id_artiste = concert.id_artiste;
	END LOOP;
	RETURN NEW;
END;
$$;

alter function mise_a_jour_ticket() owner to postgres;

