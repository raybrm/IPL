create function reservationsticket(client_id integer, concert_id integer, nombre_ticket integer) returns boolean
    language plpgsql
as
$$
DECLARE
	returnBool BOOL := FALSE;
BEGIN	
	INSERT INTO examen2019Sept.reservations VALUES(DEFAULT,concert_id, client_id, nombre_ticket) RETURNING TRUE INTO returnBool;
	
	RETURN returnBool;
END;
$$;

alter function reservationsticket(integer, integer, integer) owner to postgres;

