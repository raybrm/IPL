create function participation_concert_verification() returns trigger
    language plpgsql
as
$$
DECLARE
	date_event DATE;
BEGIN
	-- Lors de l'ajout d'un concert regarder si l'artiste n'a pas un événement le même jour --
	-- Selectionne tous les concerts de l'artiste ainsi que la date en faisant une jointure et regarde la date grace au précédent select --
	SELECT e.date FROM projet.evenements e WHERE e.id_evenement = NEW.id_evenement INTO date_event; 
	IF EXISTS (SELECT * FROM projet.concerts c , projet.evenements e 
		   WHERE e.id_evenement = c.id_evenement AND c.id_artiste = NEW.id_artiste AND e.date = date_event) THEN
			   
			   RAISE 'Impossible dajouter le concert, lartiste à déjà un événement ce jour là';
	END IF;
	RETURN NEW;
END;
$$;

alter function participation_concert_verification() owner to postgres;

