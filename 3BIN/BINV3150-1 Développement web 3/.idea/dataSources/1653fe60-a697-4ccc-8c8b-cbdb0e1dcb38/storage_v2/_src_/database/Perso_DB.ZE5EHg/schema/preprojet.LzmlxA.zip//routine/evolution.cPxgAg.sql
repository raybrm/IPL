create function evolution(compte character) returns SETOF record
    language plpgsql
as
$$
DECLARE
		balance INTEGER :=0;
		operation RECORD;
		avecQui CHARACTER(10);
		sortie RECORD;
BEGIN
		IF NOT EXISTS (SELECT * FROM preprojet.comptes c WHERE c.numero = compte) THEN RAISE 'compte invalide'; 
		END IF;
		FOR operation IN (SELECT* FROM preprojet.operations o WHERE o.compte_source = compte OR o.compte_destination = compte ORDER BY o.date_operation) LOOP
				IF (operation.compte_source = compte) THEN 
					avecQui := operation.compte_destination;
					balance := balance - operation.montant;
				ELSE
					avecQui := operation.compte_source;
					balance := balance + operation.montant;
				END IF;
				SELECT operation.date_operation, avecQui, balance INTO sortie;
				-- Avec Return next la fonction continue de tourner --
				RETURN NEXT sortie;
		END LOOP;
		RETURN;
END;
$$;

alter function evolution(char) owner to postgres;

