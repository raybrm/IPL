create function update_solde() returns trigger
    language plpgsql
as
$$
DECLARE
		ancien_solde INTEGER :=0;
BEGIN
		-- mise à jour du solde de la source --
		SELECT c.solde FROM preprojet.comptes c WHERE c.numero = NEW.compte_source INTO ancien_solde;
		UPDATE preprojet.comptes SET solde = ancien_solde - NEW.montant WHERE numero = NEW.compte_source;
		
		-- mise à jour du solde du destinataire --
		SELECT c.solde FROM preprojet.comptes c WHERE c.numero = NEW.compte_destination INTO ancien_solde;
		UPDATE preprojet.comptes SET solde = ancien_solde + NEW.montant WHERE numero = NEW.compte_destination;
		
		RETURN NEW;
		
END;
$$;

alter function update_solde() owner to postgres;

