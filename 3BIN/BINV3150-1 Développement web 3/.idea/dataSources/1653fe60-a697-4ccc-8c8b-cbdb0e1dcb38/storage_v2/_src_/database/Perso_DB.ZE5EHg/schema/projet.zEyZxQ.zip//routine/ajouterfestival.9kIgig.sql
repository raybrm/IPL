create function ajouterfestival(nom character varying) returns integer
    language plpgsql
as
$$
DECLARE
	id INTEGER;
BEGIN
	INSERT INTO projet.festivals (id_festival, nom_festival)
	VALUES (DEFAULT, nom ) RETURNING id_festival INTO id;
	
	RETURN id;
END;
$$;

alter function ajouterfestival(varchar) owner to postgres;

