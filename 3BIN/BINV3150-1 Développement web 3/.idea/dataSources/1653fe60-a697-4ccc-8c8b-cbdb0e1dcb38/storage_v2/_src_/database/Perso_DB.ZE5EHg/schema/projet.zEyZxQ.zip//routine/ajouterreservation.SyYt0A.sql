create function ajouterreservation(id_event integer, id_utilisateur integer, nbr_tickets_reserve integer) returns integer
    language plpgsql
as
$$
DECLARE
	id INTEGER;
	count INTEGER;
BEGIN
	SELECT count(r.id_reservation)
	FROM projet.reservations r
	WHERE r.id_evenement = id_event
	INTO count;	

	INSERT INTO projet.reservations (id_reservation, id_evenement, id_utilisateur, nb_tickets_reserve)
	VALUES (count+1, id_event, id_utilisateur, nbr_tickets_reserve)  RETURNING id_reservation INTO id;
	
	RETURN id;
END;
$$;

alter function ajouterreservation(integer, integer, integer) owner to postgres;

