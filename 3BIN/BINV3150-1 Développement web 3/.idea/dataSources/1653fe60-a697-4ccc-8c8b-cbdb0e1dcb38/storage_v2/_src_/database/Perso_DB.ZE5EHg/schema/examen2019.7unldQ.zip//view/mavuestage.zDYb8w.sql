create view mavuestage(sport, intitule, numero_semaine, nombre_enfant_inscrit) as
SELECT s.sport,
       s.intitule,
       s.numero_semaine,
       COALESCE(count(i.id_stage), 0::bigint) AS nombre_enfant_inscrit
FROM examen2019.stages s
         LEFT JOIN examen2019.inscriptions i ON s.id_stage = i.id_stage
GROUP BY s.id_stage;

alter table mavuestage
    owner to postgres;

