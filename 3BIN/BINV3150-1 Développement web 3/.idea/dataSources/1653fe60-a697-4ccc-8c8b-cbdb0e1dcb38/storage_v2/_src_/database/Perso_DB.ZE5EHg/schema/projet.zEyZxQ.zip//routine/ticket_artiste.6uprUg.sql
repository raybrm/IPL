create function ticket_artiste() returns trigger
    language plpgsql
as
$$
DECLARE
	tickets_vendu INTEGER := 0;
BEGIN
	-- Dans le cas où on ajoute un concert à un événement, il faut mettre à jour les tickets de l'artiste --
	-- en additionnant tous les tickets déjà vendu pour cet événement--
	SELECT SUM(nb_tickets_reserve) 
	FROM projet.reservations r 
	WHERE r.id_evenement = NEW.id_evenement 
	GROUP BY r.id_evenement INTO tickets_vendu;
				
	IF (tickets_vendu is null) THEN tickets_vendu := 0; END IF;
	
	UPDATE projet.artistes
	SET nb_tickets_vendu = nb_tickets_vendu + tickets_vendu
	WHERE id_artiste = NEW.id_artiste;
	
	RETURN NEW;
END;
$$;

alter function ticket_artiste() owner to postgres;

