create function ajouterevenement(nom character varying, date date, prix numeric, id_festival integer, id_salle integer) returns integer
    language plpgsql
as
$$
DECLARE
	id INTEGER;
BEGIN
	INSERT INTO projet.evenements (id_evenement, nom_evenement, date, prix, id_festival, id_salle)
	VALUES (DEFAULT, nom, date, prix, id_festival, id_salle) RETURNING id_evenement INTO id;
	
	RETURN id;
END;
$$;

alter function ajouterevenement(varchar, date, numeric, integer, integer) owner to postgres;

