create function ajouterconcert(id_evenement integer, id_artiste integer, heure_debut time without time zone) returns integer
    language plpgsql
as
$$
DECLARE
	id INTEGER;
BEGIN
	INSERT INTO projet.concerts (id_concert, id_evenement, id_artiste, heure_debut)
	VALUES (DEFAULT, id_evenement, id_artiste, heure_debut)  RETURNING id_concert INTO id;
	
	RETURN id;
END;
$$;

alter function ajouterconcert(integer, integer, time) owner to postgres;

