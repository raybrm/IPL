create function inserttransaction(character varying, character varying, character, character varying, character varying, character, timestamp without time zone, integer) returns integer
    language plpgsql
as
$$
DECLARE
	nom_source ALIAS FOR $1 ;
	prenom_source ALIAS FOR $2;
	compte_source ALIAS FOR $3;
	nom_destination ALIAS FOR $4 ;
	prenom_destination ALIAS FOR $5;
	compte_destination ALIAS FOR $6;
	date_operation ALIAS FOR $7;
	montant_operation ALIAS FOR $8;
	id INTEGER := 0;
BEGIN 
	-- Si l'utilisateur source et son comptes n'existe pas --
	IF  NOT EXISTS (SELECT * FROM preprojet.utilisateurs u, preprojet.comptes c
				WHERE u.prenom =  prenom_source 
				AND u.nom = nom_source
				AND u.id_utilisateur = c.id_utilisateur
				AND c.numero = compte_source) THEN 
						   
		RAISE foreign_key_violation;
	END IF;	

	IF  NOT EXISTS (SELECT * FROM preprojet.utilisateurs u, preprojet.comptes c
				WHERE u.prenom =  prenom_destination 
				AND u.nom = nom_destination
				AND u.id_utilisateur = c.id_utilisateur
				AND c.numero = compte_destination) THEN 
						   
		RAISE foreign_key_violation;
	END IF;
	
	-- si on est rentré dans un des if, le code qui suit ne saura pas executer --
	-- Donc là les 2 clients existents avec leurs compte --
	INSERT INTO preprojet.operations VALUES(DEFAULT, compte_source, compte_destination, date_operation, montant_operation)
		RETURNING id_operation INTO id;
	
	RETURN id;
	
END;

$$;

alter function inserttransaction(varchar, varchar, char, varchar, varchar, char, timestamp, integer) owner to postgres;

