create function reserverfestival(festival_id integer, id_utilisateur integer, nbr_tickets_reserve integer) returns integer
    language plpgsql
as
$$
DECLARE
	evenement RECORD;
	return_id_festival INTEGER := -1;
BEGIN
	-- Selectionne tous les événements du festival --
	FOR evenement IN (SELECT e.id_evenement FROM projet.evenements e WHERE e.id_festival = festival_id) LOOP
		PERFORM projet.ajouterReservation(evenement.id_evenement,id_utilisateur,nbr_tickets_reserve);
		return_id_festival = festival_id;
	END LOOP;
	RETURN return_id_festival;
END;
$$;

alter function reserverfestival(integer, integer, integer) owner to postgres;

