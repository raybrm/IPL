create view affichagereservations (id_utilisateur, id_reservation, nom_event, date, salle, nb_tickets_reserve) as
SELECT r.id_utilisateur,
       r.id_reservation,
       ae.nom AS nom_event,
       ae.date,
       ae.salle,
       r.nb_tickets_reserve
FROM projet.reservations r,
     projet.affichageevenements ae
WHERE r.id_evenement = ae.id_event
ORDER BY ae.date DESC;

alter table affichagereservations
    owner to postgres;

