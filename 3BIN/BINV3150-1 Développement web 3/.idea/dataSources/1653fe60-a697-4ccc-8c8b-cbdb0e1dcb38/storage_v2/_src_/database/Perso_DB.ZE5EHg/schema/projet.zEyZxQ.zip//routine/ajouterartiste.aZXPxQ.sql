create function ajouterartiste(nom character varying, nationalite character varying) returns integer
    language plpgsql
as
$$
DECLARE
	id INTEGER;
BEGIN
	INSERT INTO projet.artistes (id_artiste, nom_artiste, nationalite, nb_tickets_vendu)
	VALUES (DEFAULT, nom, nationalite, DEFAULT) RETURNING id_artiste INTO id;
	
	RETURN id;
END;
$$;

alter function ajouterartiste(varchar, varchar) owner to postgres;

