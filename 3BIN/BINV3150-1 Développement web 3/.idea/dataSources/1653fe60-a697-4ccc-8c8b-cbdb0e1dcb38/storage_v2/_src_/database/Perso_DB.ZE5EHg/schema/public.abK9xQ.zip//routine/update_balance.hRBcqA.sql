create function update_balance() returns trigger
    language plpgsql
as
$$
DECLARE
	record RECORD;
BEGIN
	-- mise à jour de la balance de tous les comptes de l'utilisateur source --
	SELECT u.balance_utilisateur, u.id_utilisateur FROM preprojet.comptes c, preprojet.utilisateurs u
												   WHERE c.numero = NEW.compte_source
												   AND c.id_utilisateur = u.id_utilisateur
												   INTO record;
	UPDATE preprojet.utilisateurs SET balance_utilisateur = record.balance_utilisateur - NEW.montant WHERE id_utilisateur = record.id_utilisateur;
	
	--mise à jour de la balance de tous les comptes de l'utilisateur destination --
	SELECT u.balance_utilisateur, u.id_utilisateur FROM preprojet.comptes c, preprojet.utilisateurs u
												   WHERE c.numero = NEW.compte_destination
												   AND c.id_utilisateur = u.id_utilisateur
												   INTO record;
	UPDATE preprojet.utilisateurs SET balance_utilisateur = record.balance_utilisateur + NEW.montant WHERE id_utilisateur = record.id_utilisateur;
	
	RETURN NEW;
END;
$$;

alter function update_balance() owner to postgres;

