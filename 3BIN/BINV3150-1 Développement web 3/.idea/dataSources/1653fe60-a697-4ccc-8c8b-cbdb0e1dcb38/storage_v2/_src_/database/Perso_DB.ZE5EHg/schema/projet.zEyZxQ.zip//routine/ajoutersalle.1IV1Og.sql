create function ajoutersalle(nom character varying, ville character varying, capacite integer) returns integer
    language plpgsql
as
$$
DECLARE
	id INTEGER;
BEGIN
	INSERT INTO projet.salles (id_salle, nom_salle, ville, capacite ) 
	VALUES (DEFAULT, nom, ville, capacite) RETURNING id_salle INTO id;
	
	RETURN id;
END;
$$;

alter function ajoutersalle(varchar, varchar, integer) owner to postgres;

