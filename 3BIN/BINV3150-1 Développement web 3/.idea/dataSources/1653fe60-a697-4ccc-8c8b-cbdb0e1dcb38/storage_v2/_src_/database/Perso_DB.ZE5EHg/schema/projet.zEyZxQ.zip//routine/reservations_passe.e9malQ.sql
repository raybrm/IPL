create function reservations_passe() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
	-- Pas de reservation si l'évenement est déjà passé --
	-- Si l'événement à une date plus petite que la date actuelle alors on raise -- 
	IF EXISTS (SELECT * FROM projet.evenements WHERE id_evenement = NEW.id_evenement AND DATE(NOW()) > date) THEN 
		RAISE 'Reservation impossible levenement est déjà passé ';
	END IF;
	RETURN NEW;
END;
$$;

alter function reservations_passe() owner to postgres;

