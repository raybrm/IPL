import React from 'react'

const Loading = () => {
    return (
        <p>Loading....</p>
    )
}

export default Loading