import React from 'react';

const Part = (props) => {
    return (
      <p> {props.part} {props.exercise} </p>
    )
  }
  
export default Part