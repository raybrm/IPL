import React from 'react'

const Person = ({name}) => {
    return <li>{name}</li>
}

export default Person