import React from 'react'

const Display = ({ counter }) => <div>{counter}</div>

export default Display