# API

## Installation

Cet projet a été créé à l'aide de create-react-app, avec NodeJS. Pour cela, installez la dernière version LTS depuis le site internet https://nodejs.org/en/

Pour installer les dépendances du projet, utilisez la commande `npm install`

## Développement

Pour développer, utilisez la commande `npm start`. Ceci écoute les modifications dans les fichiers, et relance le serveur de développement automatiquement lorsque c'est nécessaire.