import React from 'react';


const Navbar = () => {
  return (
    <>
      <div>
        <a href="/calendar">Calendrier</a>
        <a href="/config">Configuration</a>
      </div>
      <hr />
    </>
  );
}

export default Navbar;
