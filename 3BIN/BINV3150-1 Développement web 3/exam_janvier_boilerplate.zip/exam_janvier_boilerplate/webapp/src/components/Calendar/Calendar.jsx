import React from 'react';


const Calendar = () => {

  return (
    <div>
      <h1>Calendrier des désastres de 2021</h1>
        <ul>
          <li>5/24/2021, 6:40:26 PM - une pandémie de Covid-21 touche l'IPL</li>
          <li>8/30/2021, 6:34:55 PM - un incendie ravage l'IPL</li>
          <li>10/20/2021, 3:47:41 PM - des météorites détruisent Bruxelles</li>
          <li>11/10/2021, 3:09:28 PM - une pandémie de Covid-21 touche la Belgique</li>
        </ul>
    </div>
  );
}

export default Calendar;
  