import React from 'react';

import Calendar from 'components/Calendar/Calendar';
import Navbar from 'components/Navbar/Navbar';
import Settings from 'components/Settings/Settings';


const App = () => {

  return (
    <div>
        <Navbar />
        <Calendar />
        <Settings />
    </div>
  );
}

export default App;
