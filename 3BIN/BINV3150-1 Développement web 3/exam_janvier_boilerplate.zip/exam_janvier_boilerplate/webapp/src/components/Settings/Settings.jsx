import React from 'react';


const Settings = () => {

  return (
    <div>
      <h1>Configuration</h1>
    </div>
  )

}

export default Settings;
  