package be.ipl.archpae.bizz.dto;

public interface UserDTO {
	String getLogin();
}
