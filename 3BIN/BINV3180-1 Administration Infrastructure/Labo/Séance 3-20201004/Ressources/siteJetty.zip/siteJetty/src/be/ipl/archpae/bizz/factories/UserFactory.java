package be.ipl.archpae.bizz.factories;

import be.ipl.archpae.bizz.dto.UserDTO;

public interface UserFactory {
	UserDTO createUser();
}
